public class TowerOfHanoi {
	static int count = 0;

    // Function to print all moves for n disks
    public static void towerOfHanoi(int n, char from, char to, char aux) {
    	
        if (n == 1) {
        	//count = 0;
            count = count + 1;
            System.out.println("Step: "+ count+" Move disk 1 from rod " + from + " to rod " + to);
            return;
        }
        

        // Step 1: Move top n-1 disks from 'from' to 'aux' using 'to' as auxiliary
        towerOfHanoi(n - 1, from, aux, to);
        //count = 0;
        count = count + 1;

        // Step 2: Move the nth disk from 'from' to 'to'
        System.out.println("Step: "+ count+ " Move disk " + n + " from rod " + from + " to rod " + to);

        // Step 3: Move n-1 disks from 'aux' to 'to' using 'from' as auxiliary
        
        towerOfHanoi(n - 1, aux, to, from);
        //count = 0;
        
    }
    
    public static int towerOfHanoi(int n, char from, char to, char aux, int count) {
    	 if (n == 1) {
         	//count = 0;
             count = count + 1;
             System.out.println("Step: "+ count+" Move disk 1 from rod " + from + " to rod " + to);
             return count;
         }
    	 
    	 count = towerOfHanoi(n-1, from, aux, to, count);
    	 count++;
    	 
    	 System.out.println("Step: "+ count+ " Move disk " + n + " from rod " + from + " to rod " + to);
    	 
    	 count = towerOfHanoi(n-1, aux, to, from, count);
    	 
    	 return count;
    	 
    }
    
    public static void PrintNames (String P1, String P2, int n) {
    	if(n==0) {
    		return;
    	}
    		
    	PrintNames(P2, P1,n-1);
    	System.out.println("Frame: "+ n);
    	System.out.println("Name of person 1 is "+ P1);
    	System.out.println("Name of person 2 is "+ P2);
    	
    }
    
    public static void PrintRange(int[] arr, int i, int j) {
    	if(j>=i) {
        	System.out.println(arr[i]);
        	PrintRange(arr, ++i, j);
        	//i++;
    	}
    	
    }

    public static void main(String[] args) {
//        int n = 3; // number of disks
//        System.out.println("Steps to solve Tower of Hanoi for " + n + " disks:");
//        towerOfHanoi(n, 'A', 'C', 'B',0); // rods: A=from, C=to, B=aux
//    	
//    	PrintNames("Sunit", "Mak", 3);
    	
    	int[] arr = {10, 20, 30, 40, 50};
    	PrintRange(arr, 1, 3);
    }
}
