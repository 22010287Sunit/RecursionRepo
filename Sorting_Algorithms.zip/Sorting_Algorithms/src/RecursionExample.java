
public class RecursionExample {
	
	public static boolean PalindromeCheck(String str) {
		int n = str.length();
		if(str.length()<=1) {
			return true;
		}
		if(str.charAt(0)==str.charAt(n-1)) {
			return PalindromeCheck(str.substring(1,n-1));	 
		}
		return false;
		
	}
	
	public static String reverseString(String str) {
		if(str.length()<=1) {
			return str;
		}
		return reverseString(str.substring(1)) + str.charAt(0);
	}
	
	public static int digitSum(int n) {
		int sum = 0;
		if(n> 0) {
			 sum = n%10 + digitSum(n/10);
		}
		return sum;
	}
	
	public static int[] Recursive(int m, int n) {
	    while (m < n) {
	        m += 5;
	        n -= 5;
	        try {
	        	return Recursive(m, n);
	        }catch(StackOverflowError e) {
	        	System.out.println(e);
	        	return new int[] {0,0};
	        }
	        
	    }
	    return new int[]{m, n};
	}
	public static void mystery(int n) { // giving output as 2^n-1
	    if (n == 0)
	        return;
	    mystery(n - 1);
	    System.out.println(n);
	    mystery(n - 1);
	}
	
	public static void PrintNum(int n) {
		if(n>0) {
			PrintNum(n-1);
			System.out.println(n);
			
		}	
	}

	public static void main(String[] args) {
//		try {
//			int[] res = Recursive(0, 4000);
//			System.out.println("a: " + res[0] + " b: " + res[1]);
//		}
//	    catch(StackOverflowError e) {
//	    	System.out.println(e);
//	    }
		//mystery(3);
		PrintNum(5);
		
		int x = digitSum(432156);
		System.out.println(x);
		
		String Str = reverseString("ANSRK");
		System.out.println(Str);
		
		boolean B = PalindromeCheck("RACECAR");
		System.out.println(B);
	    
	}



}
