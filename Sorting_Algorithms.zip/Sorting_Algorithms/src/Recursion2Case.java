
public class Recursion2Case {
	public static void greet(int n) {
	    if (n == -1)
	        return;
	    
	    
	    System.out.println("Hello " + n);
	    
	    System.out.println("Bye " + n);
	   
	    greet(n - 1);
	    
	    
	    System.out.println("After return, n = " + n);
	}
	
	public static int Calc(int n) {
		if(n==1) {
			return 1;
		}
		int A = Calc(n-1);
		int C = 1;
		int B = Calc(n-1);
		
		return A+B+C;
		
	}
	
	public static void main(String[] args) {
		//greet(3);
		int result = Calc(4);
		System.out.println(result);
	}


}
