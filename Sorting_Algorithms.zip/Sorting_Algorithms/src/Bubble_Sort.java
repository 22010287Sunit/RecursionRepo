
public class Bubble_Sort {
	public static void swapNumbers(int[]arr,int i, int j) {
		int temp = arr[i] ;
		arr[i] = arr[j];
		 arr[j] = temp;
	}
	
	public static void sortArray(int[] arr) { // this works but it is not a bubblesort
		int i = 0;
		int j = arr.length -1 ;
		
		
		while (i<j) {
			if(arr[i] > arr[i+1]) {
				swapNumbers(arr, i, i+1);
				i=0;	
			}
			else {
				i++;
			}
		}
		
	}
	
	public static void myBubblesort(int[] arr) {
		int n = arr.length-1;
		for(int i=0; i< arr.length; i++) {
			for(int j=0; j<= n-i-1; j++) {
				if(arr[j]> arr[j+1]) {
					swapNumbers(arr, j, j+1);
				}
			}
		}
	}
	
	public static void bubbleSort(int[] arr) {
	    int n = arr.length;
	    boolean swapped;

	    for (int i = 0; i < n - 1; i++) {
	        swapped = false;

	        for (int j = 0; j < n - i - 1; j++) {
	            if (arr[j] > arr[j + 1]) {
	                // swap
	                int temp = arr[j];
	                arr[j] = arr[j + 1];
	                arr[j + 1] = temp;

	                swapped = true;
	            }
	        }

	        // If no two elements were swapped → already sorted
	        if (!swapped) break;
	    }
	}
	
	
     
	public static void main(String[] args) {
		
	int [] arr1 = {1, 3, 5,4,11,33,21};
	int [] arr2 = {9, 1, 8, 2, 7, 3, 6};
	myBubblesort(arr2);
	
	for(int i=0; i< arr2.length; i++) {
		System.out.println(arr2[i]);
	}
	
	}


}
